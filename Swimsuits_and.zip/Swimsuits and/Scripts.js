function actionON(idd){
    document.getElementById(idd).style.color = "green";
    }
function actionOFF(idd){
    document.getElementById(idd).style.color = "aliceblue";
    }
function save(filename, html) {
    var el = document.createElement('a');
    el.setAttribute('href', 'data:text/html;charset=utf-8,' + encodeURIComponent(html));
    el.setAttribute('download', filename);
    el.style.display = 'none';
    document.body.appendChild(el);
    el.click();
    document.body.removeChild(el);
    }